<?php
class Employee extends BaseModel  {
	
	protected $table = 'employee';
	protected $primaryKey = 'EmployeeId';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "  SELECT employee.* FROM employee  ";
	}
	public static function queryWhere(  ){
		
		return " WHERE employee.EmployeeId IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
